<?php

namespace App\Controllers\user;

use App\Controllers\user\BaseController;
use App\Models\ProfilModel;
use App\Models\SliderModel;
use App\Models\ProdukModel;
use App\Models\ArtikelModel;
use App\Models\MetaModel;

class Homectrl extends BaseController
{
    private $ProfilModel;
    private $SliderModel;
    private $ProdukModel;
    private $ArtikelModel;
    private $MetaModel;

    public function __construct()
    {
        $this->ProfilModel = new ProfilModel();
        $this->SliderModel = new SliderModel();
        $this->ProdukModel = new ProdukModel();
        $this->ArtikelModel = new ArtikelModel();
        $this->MetaModel = new MetaModel();
    }

    public function index()
{
    // Check if the request is for 'favicon.ico' and skip further processing
    if ($this->request->getUri()->getPath() === 'favicon.ico') {
        return;
    }

    // Existing code to fetch data, including meta data for the page
    $pageName = 'Beranda'; 
    $meta = $this->MetaModel->where('nama_halaman', $pageName)->first();

    // Fetch other required data
    $data = [
        'profil' => $this->ProfilModel->findAll(),
        'tbslider' => $this->SliderModel->findAll(),
        'tbproduk' => $this->ProdukModel->findAll(),
        'artikelterbaru' => $this->ArtikelModel->getArtikelTerbaru(),
        'meta' => $meta,  // Pass the meta data to the view
    ];

    $locale = session('lang') ?? 'id';
    $data['locale'] = $locale;

    // Set page title and description based on locale


    helper('text');
    
    // Set locale-based description
    $teks = strip_tags($locale === 'id' ? $data['profil'][0]->deskripsi_perusahaan_in : $data['profil'][0]->deskripsi_perusahaan_en);
    $data['Meta'] = character_limiter($teks, 150);

    // Load the view
    return view('user/home/index', $data);
}

    public function redirectToHome()
    {
        // Get the current locale and redirect accordingly
        $locale = session('lang') ?? 'id'; // Default to 'id' if not set
        return redirect()->to(base_url($locale . '/home'));
    }

    public function language($locale)
    {
        // Set the new locale
        service('request')->setLocale($locale);
        session()->set('lang', $locale); // Save the selected locale in the session
        // Redirect to the home page or wherever needed
        return redirect()->to(base_url($locale));
    }
}
