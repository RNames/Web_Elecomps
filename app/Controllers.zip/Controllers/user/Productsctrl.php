<?php

namespace App\Controllers\user;

use App\Controllers\user\BaseController;
use App\Models\ProfilModel;
use App\Models\SliderModel;
use App\Models\ProdukModel;
use App\Models\MetaModel;

class Productsctrl extends BaseController
{
    private $ProfilModel;
    private $SliderModel;
    private $ProdukModel;
    private $MetaModel;

    public function __construct()
    {
        $this->ProfilModel = new ProfilModel();
        $this->SliderModel = new SliderModel();
        $this->ProdukModel = new ProdukModel();
        $this->MetaModel = new MetaModel();
    }

    public function index()
    {

        $pageName = 'Layanan'; 
        $meta = $this->MetaModel->where('nama_halaman', $pageName)->first();

        $data = [
            'profil' => $this->ProfilModel->findAll(),
            'tbslider' => $this->SliderModel->findAll(),
            'tbproduk' => $this->ProdukModel->getAllProducts(),
            'meta' => $meta,
        ];
        helper('text');

        // Get the current language and set the necessary data
        $locale = session('lang') ?? 'id';

        $data['Title'] = $meta ? $meta['meta_title_' . $locale] : $data['profil'][0]->title_website;
        $data['Meta'] = $meta ? $meta['meta_description_' . $locale] : '';
        
        $nama_perusahaan = $data['profil'][0]->nama_perusahaan;
        $deskripsi_perusahaan = strip_tags($locale === 'id' ? $data['profil'][0]->deskripsi_perusahaan_in : $data['profil'][0]->deskripsi_perusahaan_en);

        // Using the correct product names and descriptions based on language
        $data['Title'] = isset($data['tbproduk'][0]) ? ($locale === 'id' ? $data['tbproduk'][0]->nama_produk_in : $data['tbproduk'][0]->nama_produk_en) : 'Produk';
        $teks = ($locale === 'id' ? "Produk dari $nama_perusahaan. $deskripsi_perusahaan" : "Products of $nama_perusahaan. $deskripsi_perusahaan");

        $batasan = 150;
        $data['Meta'] = character_limiter($teks, $batasan);

        $data['locale'] = session('lang') ?? 'id';

        return view('user/products/index', $data);
    }

    public function detail($slug)
    {
        // Get the current locale
        $locale = session('lang');

        // Fetch the product by slug
        $produk = $this->ProdukModel->getProductBySlug($slug, $locale);

        // Check if the product was found
        if (!$produk) {
            // Redirect to an error page or show an error message
            return redirect()->to('/')->with('error', 'Product not found');
        }

        // Prepare the data to be passed to the view
        $data = [
            'profil' => $this->ProfilModel->findAll(),
            'tbproduk' => $produk, // Use the fetched product
        ];

        helper('text');

        // Get the product name and description based on the current language
        $nama_produk = $locale === 'id' ? $produk->nama_produk_in : $produk->nama_produk_en;
        $deskripsi_produk = strip_tags($locale === 'id' ? $produk->deskripsi_produk_in : $produk->deskripsi_produk_en);

        $data['Title'] = $nama_produk ?? '';
        $teks = "$nama_produk. $deskripsi_produk";

        $batasan = 150;
        $data['Meta'] = character_limiter($teks, $batasan);
        $data['locale'] = $locale ?? 'en';

        return view('user/products/detail', $data);
    }
}
