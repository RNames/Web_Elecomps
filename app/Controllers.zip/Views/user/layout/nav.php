<div class="container-fluid bg-white sticky-top" style="height: 75px;">
    <?php foreach ($profil as $header) : ?>
        <div class="container">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-0">
                <a href="<?= base_url('/') ?>" class="navbar-brand d-flex align-items-center" style="height: 63px;">
                    <img class="img-fluid logo-img" src="<?= base_url('asset-user/images/' . $header->logo_perusahaan) ?>" alt="Logo">
                </a>
                <button type="button" class="navbar-toggler ms-auto" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ms-auto d-flex align-items-center">
                        <li class="nav-item">
                            <a href="<?= base_url($locale . '') ?>" class="nav-link <?php if (current_url() == base_url($locale . '') || current_url() == base_url('')) echo 'active'; ?>">
                                <?php echo lang('Blog.headerHome'); ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= base_url(($locale === 'en' ? $locale .  '/about' : $locale . '/tentang')) ?>" class="nav-link <?php if (current_url() == base_url(($locale === 'en' ? $locale .  '/about' : $locale . '/tentang'))) echo 'active'; ?>">
                                <?php echo lang('Blog.headerAbout'); ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= base_url(($locale === 'en' ? $locale .  '/articles' : $locale . '/artikel')) ?>" class="nav-link <?php if (current_url() == base_url(($locale === 'en' ? $locale .  '/articles' : $locale . '/artikel'))) echo 'active'; ?>">
                                <?php echo lang('Blog.headerArticle'); ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= base_url(($locale === 'en' ? $locale .  '/service' : $locale . '/layanan')) ?>" class="nav-link <?php if (current_url() == base_url(($locale === 'en' ? $locale .  '/product' : $locale . '/produk'))) echo 'active'; ?>">
                                <?php echo lang('Blog.headerProducts'); ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= base_url(($locale === 'en' ? $locale .  '/activities' : $locale . '/aktivitas')) ?>" class="nav-link <?php if (current_url() == base_url(($locale === 'en' ? $locale .  '/activities' : $locale . '/aktivitas'))) echo 'active'; ?>">
                                <?php echo lang('Blog.headerActivities'); ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= base_url(($locale === 'en' ? $locale .  '/contact' : $locale . '/kontak')) ?>" class="nav-link <?php if (current_url() == base_url(($locale === 'en' ? $locale .  '/contact' : $locale . '/kontak'))) echo 'active'; ?>">
                                <?php echo lang('Blog.headerContact'); ?>
                            </a>
                        </li>

                        <li class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo lang('Blog.headerLanguange'); ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a href="<?= site_url('lang/id') ?>" class="dropdown-item">Indonesia</a></li>
                                <li><a href="<?= site_url('lang/en') ?>" class="dropdown-item">English</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    <?php endforeach; ?>
</div>

<!-- jQuery (if using Bootstrap 4 or below) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap JavaScript (make sure this is loaded after jQuery if needed) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<script>
    $(document).ready(function() {
        $(".navbar-nav a").on("click", function() {
            $(".navbar-nav").find(".active").removeClass("active");
            $(this).addClass("active");
            if ($(".navbar-collapse").hasClass("show")) {
                $(".navbar-toggler").click();
            }
        });

        // Close dropdown when clicking outside
        $(document).on('click', function(event) {
            var $trigger = $(".nav-item.dropdown");
            if ($trigger !== event.target && !$trigger.has(event.target).length) {
                $(".dropdown-menu").removeClass("show");
                $("#navbarDropdown").attr("aria-expanded", "false");
            }
        });

        // Ensure dropdown closes when clicked again
        $('.dropdown-toggle').on('click', function() {
            var isExpanded = $(this).attr('aria-expanded') === 'true';
            if (isExpanded) {
                $(this).attr('aria-expanded', 'false');
                $(this).next('.dropdown-menu').removeClass('show');
            } else {
                $(this).attr('aria-expanded', 'true');
                $(this).next('.dropdown-menu').addClass('show');
            }
        });
    });
</script>

<style>
    .logo-img {
        max-height: 70px;
        height: auto;
        max-width: 100%;
    }

    .navbar-nav .nav-link {
        display: flex;
        align-items: center;
        height: 100%;
        padding: 10px;
    }

    .navbar-toggler {
        margin-top: 10px;
    }

    /* Adjust dropdown menu for smaller screens */
    .dropdown-menu {
        position: absolute;
        z-index: 9999;
    }

    /* Media queries for responsiveness */
    @media (max-width: 991px) {
        .logo-img {
            max-height: 50px;
        }

        .navbar-nav .nav-link {
            margin-top: 10px;
            margin-bottom: 10px;
        }
    }

    @media (max-width: 768px) {
        .logo-img {
            max-height: 60px;
            margin-top: 0;
        }
    }
</style>