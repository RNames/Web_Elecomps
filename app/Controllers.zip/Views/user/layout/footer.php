<!-- Footer Start -->
<div class="container-fluid copyright py-1 mt-5">
    <div class="container">
        <div class="footer-border">
            <div class="row">
                <div class="col-xl-15">
                    <div class="footer-copy-right text-center" style="font-size: 14px;">
                        <p class="mt-3"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;<script>
                                document.write(new Date().getFullYear());
                            </script>. <?php foreach ($profil as $footer) : ?><?= $footer->teks_footer; ?><?php endforeach; ?></a> <!-- License information: https://untree.co/license/ -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->